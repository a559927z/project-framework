package com.ks.service;

import com.ks.dto.UserDto;

public interface UserService {

	/**
	 * 查询用户信息
	 *
	 * @param customerId
	 *            客户ID
	 * @param userName
	 *            用户名
	 * @param pageDto
	 *            分页dto
	 * @return
	 */
	// PaginationDto<UserDto> findAll(String customerId, String userName,
	// PaginationDto<UserDto> pageDto);

	/**
	 * 添加用户
	 *
	 * @param userDto
	 * @return
	 */
	// boolean addUser(UserDto userDto);

	/**
	 * 修改用户
	 *
	 * @param userDto
	 * @return
	 */
	// boolean editUser(UserDto userDto);

	/**
	 * 修改用户密码信息
	 * 
	 * @param passwd
	 * @param userId
	 * @return
	 */
	// boolean updateUserPasswd(String passwd, String userId, String customerId);

	/**
	 * 删除用户
	 *
	 * @param customerId
	 *            客户ID
	 * @param userIds
	 *            用户ID集合
	 * @return
	 */
	// boolean deleteUser(String customerId, List<String> userIds);

	/**
	 * 用户绑定员工
	 * 
	 * @param customerId
	 * @param userId
	 * @param empId
	 * @return
	 */
	// boolean userBindEmp(String customerId, String userId, String empId);

	/**
	 * 根据用户ID查询用户信息
	 * 
	 * @return
	 */
	UserDto findUserById(String customerId, String userId);

	String testSql();

	// List<TreeDto> dbToZtree(List<OrganDto> existOrgans);
	//
	// boolean updateUserPWDbyUserName(String enPwd, String userName, String
	// customerId);
	//
	// Integer existUser(String empId, String userName);
	//
	// Map<String, Object> findAll2(String customerId, String search, int start, int
	// length);
	//
	// /**
	// * 查出用户具备角色、功能权限
	// *
	// * @param customerId
	// * @param search
	// * @param start
	// * @param length
	// * @return
	// */
	// Map<String, Object> queryPerms(String customerId, String search, int start,
	// int length);

}
