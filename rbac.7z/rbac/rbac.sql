CREATE TABLE `dict_dim_role` (
`role_id` varchar(32) CHARACTER SET utf8 NOT NULL COMMENT '角色ID',
`customer_id` varchar(32) CHARACTER SET utf8 NULL DEFAULT NULL COMMENT '客户ID',
`role_key` varchar(20) CHARACTER SET utf8 NULL DEFAULT NULL COMMENT '角色编码',
`role_name` varchar(20) CHARACTER SET utf8 NULL DEFAULT NULL COMMENT '角色名称',
`note` varchar(200) CHARACTER SET utf8 NULL DEFAULT NULL COMMENT '描述',
`create_user_id` varchar(32) CHARACTER SET utf8 NOT NULL COMMENT '创建人',
`modify_user_id` varchar(32) CHARACTER SET utf8 NULL DEFAULT NULL COMMENT '修改人',
`create_time` varchar(255) NOT NULL COMMENT '创建时间',
`modify_time` varchar(255) NULL DEFAULT NULL COMMENT '修改时间',
`show_index` int(1) NULL DEFAULT NULL,
PRIMARY KEY (`role_id`) ,
INDEX `index_customerId` (`customer_id`),
INDEX `index_key` (`role_key`)
)
AUTO_INCREMENT=1;

CREATE TABLE `dict_relation_role_user` (
`user_role_id` varchar(32) CHARACTER SET utf8 NOT NULL,
`role_id` varchar(32) CHARACTER SET utf8 NULL DEFAULT NULL,
`user_id` varchar(32) CHARACTER SET utf8 NULL DEFAULT NULL,
`customer_id` varchar(32) CHARACTER SET utf8 NULL DEFAULT NULL,
`create_user_id` varchar(32) CHARACTER SET utf8 NOT NULL COMMENT '创建人',
`modify_user_id` varchar(32) CHARACTER SET utf8 NULL DEFAULT NULL COMMENT '修改人',
`create_time` varchar(255) NOT NULL COMMENT '创建时间',
`modify_time` varchar(255) NULL DEFAULT NULL COMMENT '修改时间',
PRIMARY KEY (`user_role_id`) 
)
AUTO_INCREMENT=1;

CREATE TABLE `dict_dim_user` (
`user_id` varchar(32) CHARACTER SET utf8 NOT NULL,
`customer_id` varchar(32) CHARACTER SET utf8 NULL DEFAULT NULL COMMENT '客户ID',
`emp_id` varchar(32) CHARACTER SET utf8 NULL DEFAULT NULL COMMENT '员工ID',
`user_key` varchar(20) CHARACTER SET utf8 NULL DEFAULT NULL COMMENT '用户编码',
`user_name` varchar(20) CHARACTER SET utf8 NULL DEFAULT NULL COMMENT '用户名称',
`user_name_ch` varchar(5) CHARACTER SET utf8 NULL DEFAULT NULL,
`password` varchar(100) CHARACTER SET utf8 NULL DEFAULT NULL COMMENT '密码',
`email` varchar(50) CHARACTER SET utf8 NULL DEFAULT NULL,
`note` varchar(200) CHARACTER SET utf8 NULL DEFAULT NULL COMMENT '描述',
`sys_deploy` int(1) UNSIGNED NOT NULL COMMENT '系统部署用户标识（具备配置所有功能和数据，不走角色权限走线）',
`show_index` int(5) NULL DEFAULT NULL,
`create_user_id` varchar(32) CHARACTER SET utf8 NOT NULL COMMENT '创建人',
`modify_user_id` varchar(32) CHARACTER SET utf8 NULL DEFAULT NULL COMMENT '修改人',
`create_time` varchar(255) NOT NULL COMMENT '创建时间',
`modify_time` varchar(255) NULL DEFAULT NULL COMMENT '修改时间',
`is_lock` varchar(255) NULL DEFAULT NULL,
PRIMARY KEY (`user_id`) ,
INDEX `index_customerId` (`customer_id`),
INDEX `index_key` (`user_key`),
INDEX `index_username` (`user_name`),
INDEX `index_pwd` (`password`)
)
AUTO_INCREMENT=1;

CREATE TABLE `dict_relation_role_function` (
`function_role_id` varchar(32) CHARACTER SET utf8 NOT NULL,
`role_id` varchar(32) CHARACTER SET utf8 NULL DEFAULT NULL,
`function_id` varchar(32) CHARACTER SET utf8 NULL DEFAULT NULL,
`customer_id` varchar(32) CHARACTER SET utf8 NULL DEFAULT NULL,
`item_codes` varchar(200) CHARACTER SET utf8 NULL DEFAULT NULL COMMENT '多个用，号隔开',
`create_user_id` varchar(32) CHARACTER SET utf8 NOT NULL COMMENT '创建人',
`modify_user_id` varchar(32) CHARACTER SET utf8 NULL DEFAULT NULL COMMENT '修改人',
`create_time` varchar(255) NOT NULL COMMENT '创建时间',
`modify_time` varchar(255) NULL DEFAULT NULL COMMENT '修改时间',
PRIMARY KEY (`function_role_id`) 
)
AUTO_INCREMENT=1;

CREATE TABLE `dict_dim_function` (
`function_id` varchar(32) CHARACTER SET utf8 NOT NULL COMMENT '功能ID',
`customer_id` varchar(32) CHARACTER SET utf8 NULL DEFAULT NULL COMMENT '客户ID',
`function_key` varchar(20) CHARACTER SET utf8 NULL DEFAULT NULL COMMENT '功能编码',
`function_name` varchar(20) CHARACTER SET utf8 NULL DEFAULT NULL COMMENT '功能名称',
`function_parent_id` varchar(32) CHARACTER SET utf8 NULL DEFAULT NULL COMMENT '上级功能',
`url` varchar(200) CHARACTER SET utf8 NULL DEFAULT NULL COMMENT '连接',
`is_menu` int(11) NULL DEFAULT NULL COMMENT '是否菜单',
`show_index` int(11) NULL DEFAULT NULL COMMENT '排序',
`full_path` text CHARACTER SET utf8 NULL COMMENT '全路径',
`note` varchar(200) CHARACTER SET utf8 NULL DEFAULT NULL COMMENT '描述',
`create_user_id` varchar(32) CHARACTER SET utf8 NOT NULL COMMENT '创建人',
`modify_user_id` varchar(32) CHARACTER SET utf8 NULL DEFAULT NULL COMMENT '修改人',
`create_time` varchar(255) NOT NULL COMMENT '创建时间',
`modify_time` varchar(255) NULL DEFAULT NULL COMMENT '修改时间',
`quota_or_fun` varchar(255) NULL DEFAULT NULL COMMENT '1指标，2功能，3其它',
PRIMARY KEY (`function_id`) ,
INDEX `index_customerId` (`customer_id`),
INDEX `index_key` (`function_key`),
INDEX `index_parentId` (`function_parent_id`)
)
AUTO_INCREMENT=1;

CREATE TABLE `dict_dim_function_item` (
`function_item_id` varchar(32) CHARACTER SET utf8 NOT NULL COMMENT '功能操作ID',
`customer_id` varchar(32) CHARACTER SET utf8 NULL DEFAULT NULL COMMENT '客户ID',
`function_id` varchar(32) CHARACTER SET utf8 NULL DEFAULT NULL COMMENT '功能ID',
`item_code` varchar(20) CHARACTER SET utf8 NULL DEFAULT NULL COMMENT '操作项',
`note` varchar(200) CHARACTER SET utf8 NULL DEFAULT NULL COMMENT '描述',
`create_user_id` varchar(32) CHARACTER SET utf8 NOT NULL COMMENT '创建人',
`modify_user_id` varchar(32) CHARACTER SET utf8 NULL DEFAULT NULL COMMENT '修改人',
`create_time` varchar(255) NOT NULL COMMENT '创建时间',
`modify_time` varchar(255) NULL DEFAULT NULL COMMENT '修改时间',
PRIMARY KEY (`function_item_id`) 
)
AUTO_INCREMENT=1;

CREATE TABLE `dict_dim_organization` (
`organization_id` varchar(32) CHARACTER SET utf8 NOT NULL,
`customer_id` varchar(32) CHARACTER SET utf8 NULL DEFAULT NULL,
`organization_company_id` char(32) CHARACTER SET utf8 NULL DEFAULT NULL COMMENT '分公司',
`organization_type_id` varchar(32) CHARACTER SET utf8 NULL DEFAULT NULL,
`organization_key` varchar(20) CHARACTER SET utf8 NULL DEFAULT NULL COMMENT '机构编码',
`organization_parent_key` varchar(20) CHARACTER SET utf8 NULL DEFAULT NULL,
`organization_parent_id` char(32) CHARACTER SET utf8 NULL DEFAULT NULL COMMENT '上级机构',
`organization_name` varchar(20) CHARACTER SET utf8 NULL DEFAULT NULL COMMENT '机构名称',
`organization_name_full` varchar(50) CHARACTER SET utf8 NULL DEFAULT NULL,
`note` varchar(100) CHARACTER SET utf8 NULL DEFAULT NULL COMMENT '描述',
`is_single` varchar(255) NULL DEFAULT 0 COMMENT '是否独立核算',
`full_path` text CHARACTER SET utf8 NULL COMMENT '业务单位ID',
`has_children` varchar(255) NULL DEFAULT NULL,
`depth` int(3) NULL DEFAULT NULL,
`profession_id` varchar(32) CHARACTER SET utf8 NULL DEFAULT NULL,
`city_id` varchar(32) CHARACTER SET utf8 NULL DEFAULT NULL,
`refresh` varchar(255) NULL DEFAULT NULL,
`c_id` varchar(32) CHARACTER SET utf8 NULL DEFAULT NULL,
`show_index` int(2) NULL DEFAULT NULL,
PRIMARY KEY (`organization_id`) ,
INDEX `index_orgId` (`organization_id`),
INDEX `index_fp` (`full_path`),
INDEX `ind_cId_dim_organization` (`city_id`)
)
AUTO_INCREMENT=1;

CREATE TABLE `dict_relation_role_organization` (
`role_organization_id` varchar(32) CHARACTER SET utf8 NOT NULL,
`customer_id` varchar(32) CHARACTER SET utf8 NULL DEFAULT NULL,
`role_id` varchar(32) CHARACTER SET utf8 NULL DEFAULT NULL COMMENT 'UUID32',
`organization_id` varchar(32) CHARACTER SET utf8 NULL DEFAULT NULL,
`half_check` int(1) UNSIGNED NULL DEFAULT NULL COMMENT '为0是代表：配置机构数据时全勾状态，应为数据权限。',
`create_user_id` varchar(32) CHARACTER SET utf8 NULL DEFAULT NULL COMMENT '创建人',
`modify_user_id` varchar(32) CHARACTER SET utf8 NULL DEFAULT NULL COMMENT '修改人',
`create_time` varchar(255) NULL DEFAULT NULL COMMENT '创建时间',
`modify_time` varchar(255) NULL DEFAULT NULL COMMENT '修改时间',
PRIMARY KEY (`role_organization_id`) ,
INDEX `index_customerId` (`customer_id`),
INDEX `index_halfCheck` (`half_check`)
)
AUTO_INCREMENT=1;


ALTER TABLE `dict_dim_role` ADD CONSTRAINT `fk_dict_dim_role_dict_relation_role_user_1` FOREIGN KEY (`role_id`) REFERENCES `dict_relation_role_user` (`role_id`);
ALTER TABLE `dict_relation_role_user` ADD CONSTRAINT `fk_dict_relation_role_user_dict_dim_user_1` FOREIGN KEY (`user_id`) REFERENCES `dict_dim_user` (`user_id`);
ALTER TABLE `dict_dim_role` ADD CONSTRAINT `fk_dict_dim_role_dict_relation_role_function_1` FOREIGN KEY (`role_id`) REFERENCES `dict_relation_role_function` (`role_id`);
ALTER TABLE `dict_dim_role` ADD CONSTRAINT `fk_dict_dim_role_dict_relation_role_organization_1` FOREIGN KEY (`role_id`) REFERENCES `dict_relation_role_organization` (`role_id`);
ALTER TABLE `dict_relation_role_function` ADD CONSTRAINT `fk_dict_relation_role_function_dict_dim_function_1` FOREIGN KEY (`function_id`) REFERENCES `dict_dim_function` (`function_id`);
ALTER TABLE `dict_relation_role_organization` ADD CONSTRAINT `fk_dict_relation_role_organization_dict_dim_organization_1` FOREIGN KEY (`organization_id`) REFERENCES `dict_dim_organization` (`organization_id`);
ALTER TABLE `dict_dim_function_item` ADD CONSTRAINT `fk_dict_dim_function_item_dict_dim_function_1` FOREIGN KEY (`function_id`) REFERENCES `dict_dim_function` (`function_id`);

