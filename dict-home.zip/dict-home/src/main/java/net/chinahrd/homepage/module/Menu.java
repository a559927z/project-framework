/**
*net.chinahrd.cache
*/
package net.chinahrd.homepage.module;


import net.chinahrd.core.menu.MenuRegisterAbstract;

/**
 * @author htpeng
 *2016年10月11日下午11:52:52
 */
public class Menu extends MenuRegisterAbstract{

	@Override
	protected String getXmlPath() {
		return "menu.xml";
	}



}
