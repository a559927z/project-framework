package net.chinahrd.homepage.module;

import org.apache.ibatis.annotations.Param;

public interface CacheDao {

	/**
	 * 加班预警周期内有效工作日期
	 * 
	 * @return
	 */
//	Integer queryAvailabilityDayNum(@Param("customerId") String customerId,
//			@Param("curdate") String curdate, @Param("key") String key);
	
}
