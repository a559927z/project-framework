package net.chinahrd.homepage.mvc.pc.controller;

import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import net.chinahrd.eis.annotation.log.ControllerAop;
import net.chinahrd.mvc.pc.controller.BaseController;

@Controller
@RequestMapping("/home")
public class ProfileController extends BaseController {

	/**
	 * 
	 * @param request
	 * @return
	 */
	@ControllerAop(description = "跳转到用户平台")
	@RequestMapping(value = "/profile", method = RequestMethod.GET)
	public String home(HttpServletRequest request) {
		return "biz/profile";
	}

}
